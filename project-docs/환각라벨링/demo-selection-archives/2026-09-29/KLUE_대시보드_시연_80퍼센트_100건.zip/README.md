# 대시보드 연동용 80% 시연 세트

## 포함 파일
- data.json: 실제 원본 질문·답변·저장된 KLUE 예측·잠정 정답 라벨 100건
- preview.html: 브라우저에서 바로 여는 미리보기
- selection_manifest.json: 선정 ID, 설정, 해시 및 해당 선별 집합의 지표
- SUMMARY.md: 구성과 지표 설명

## 반드시 표시할 데이터 성격
**정답과 예측을 확인한 후 80건이 맞도록 100건을 사후 선별했습니다. 실제 전체 정확도나 새 질문 성능이 아닙니다. 학습 자료가 포함되며 사람 최종 승인 전 에이전트 라벨입니다.**
권장 UI 이름: ‘선별 사례 시연 모드 · 100건’. 권장 안내: ‘목표 비율에 맞춘 사후 구성 데이터 · 실시간 평가 아님’.
이 ZIP은 고정 답변/탐지 결과 재생용이며 실시간 추론 모델이나 API를 포함하지 않습니다. 실시간 질문 화면의 성능 수치로 표시하지 마세요.

## 연동
`data.items`를 사례 목록으로 사용합니다. `id`는 고유 ID, `question`은 질문, `answer`는 원본 정본 답변입니다.
`prediction.has_warning`으로 경고 여부를 표시하고 `prediction.spans`로 경고 구절을 강조합니다. 정답 표시가 필요하면 별도 `reference`를 사용하세요. 정답 라벨을 실제 모델 경고로 대신 표시하지 마세요.
`outcome`: TP=환각 포착, TN=정상 무경고, FP=정상 오탐, FN=환각 누락. 전체 오류 구절을 완벽히 포착했다는 뜻은 아닙니다.
`partition`: train=학습, dev=개발, evaluation=이미 노출된 비교 자료입니다. 독립 테스트가 아닙니다.
`evidence_references`는 당시 근거의 ID/해시입니다. 근거 원문, 전체 private 프롬프트, 모델 가중치, 인증 키는 포함하지 않았습니다. 따라서 이 파일만으로 근거 원문 열람이나 재추론은 할 수 없습니다.

## 문자열 오프셋 주의
`start`는 포함, `end`는 제외이며 Python Unicode code point 기준입니다. JavaScript UTF-16 `String.slice`와 다를 수 있습니다.
```js
const chars = Array.from(item.answer);
const quoted = chars.slice(span.start, span.end).join('');
if (quoted !== span.quote) throw new Error('offset mismatch');
```
답변을 정규화하거나 Markdown을 제거한 뒤 오프셋을 적용하지 마세요. 원문에서 먼저 위치를 계산하세요. 답변과 인용문은 textContent 등으로 이스케이프해서 표시하세요.
`checked_ranges`는 검사 구간, `unchecked_ranges`는 미검사 구간입니다. 미검사 구간을 정상 검증 완료로 표시하지 마세요.

## 검증
100건의 고유 ID, 원본 답변/예측/라벨 해시 일치, 모든 구절의 Unicode 오프셋 일치를 확인했습니다. 정답 라벨을 보고 선별했지만 원본 라벨과 예측 자체는 변경하지 않았습니다.
