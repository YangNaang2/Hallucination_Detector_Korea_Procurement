# 가상 새온에너지SW 합성 시나리오 PLAN

합성 내부 검토 자료. 실제 기관 발급 증명서·견적서가 아니다. SC-QA300-C05-A / 2.0.0

## staffing-1

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| staffing / 배치 ID | C05-R1-A1 |
| staffing / 인력 ID | C05-P-07 |
| staffing / 시작일 | 2026-06-01 |
| staffing / 종료일 | 2026-11-30 |
| staffing / 투입 FTE | 0.2 FTE · 합성 설정값 |
| staffing / planned_work | EMS 관리 |
| staffing / 값의 성격 | synthetic_setting |
| staffing / rationale | 기존 확정 배치의 잔여 가용량 안에서 역할별로 책정한 내부 작업량; 발주기관 필수 인원·등급 판정 아님 |

## staffing-2

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| staffing / 배치 ID | C05-R1-A2 |
| staffing / 인력 ID | C05-P-03 |
| staffing / 시작일 | 2026-06-01 |
| staffing / 종료일 | 2026-11-30 |
| staffing / 투입 FTE | 0.8 FTE · 합성 설정값 |
| staffing / planned_work | 전력 제어 개발 |
| staffing / 값의 성격 | synthetic_setting |
| staffing / rationale | 기존 확정 배치의 잔여 가용량 안에서 역할별로 책정한 내부 작업량; 발주기관 필수 인원·등급 판정 아님 |

## staffing-3

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| staffing / 배치 ID | C05-R1-A3 |
| staffing / 인력 ID | C05-P-04 |
| staffing / 시작일 | 2026-06-01 |
| staffing / 종료일 | 2026-11-30 |
| staffing / 투입 FTE | 0.8 FTE · 합성 설정값 |
| staffing / planned_work | SW 구현 |
| staffing / 값의 성격 | synthetic_setting |
| staffing / rationale | 기존 확정 배치의 잔여 가용량 안에서 역할별로 책정한 내부 작업량; 발주기관 필수 인원·등급 판정 아님 |

## staffing-4

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| staffing / 배치 ID | C05-R1-A4 |
| staffing / 인력 ID | C05-P-06 |
| staffing / 시작일 | 2026-06-01 |
| staffing / 종료일 | 2026-11-30 |
| staffing / 투입 FTE | 0.3 FTE · 합성 설정값 |
| staffing / planned_work | 품질 시험 |
| staffing / 값의 성격 | synthetic_setting |
| staffing / rationale | 기존 확정 배치의 잔여 가용량 안에서 역할별로 책정한 내부 작업량; 발주기관 필수 인원·등급 판정 아님 |

## source_period_policy

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| source_period_policy | 시작일은 합성 계획 가정일 수 있음. 실제 착수일·입찰일 확정 아님. |

## committed_execution

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| committed_execution | 아니오 |

## scenario_id

가상 새온에너지SW · C05 · astra-c05 · L2 · 상태 기준일 2026-06-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| scenario_id | SC-QA300-C05-A |
